utils::globalVariables(c("X1", "X2", 'var', 'attrib', 'colorId' ,'timestamp', 'author', 'V2',
                         'V3', 'V4', 'V5', 'V6', 'oldLen', 'charBank', 'X4', 'X3', 'kok_lerru' , 'kok_lerrun_nun',
                         'kok_aurreko_kar_kop', 'oldLen', 'bank_luzera', 'landu', 'amaieran', 'kok_lerru',
                         'changeset', 'opt','newLen',  'text', 'attribs', 'noz','aldi','azktex','kok_erlatiboa',
                         'lerro_aldaketa', 'kok_erlatiboa', 'padIDs', 'name', 'revs', 'gehi', 'jauzi', 'jauziB',
                         'seg', 'jauzia', 'rowname', 'pad'
                         ))
