## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(IDAT)

## -----------------------------------------------------------------------------
o_idat <- f_IDAT('../inst/extdata/', 'txepetx-2-lo1uvq90o.etherpad')

## -----------------------------------------------------------------------------
summary(o_idat)

## -----------------------------------------------------------------------------
require(magrittr)

o_idat$df_aldaketak |> 
    nrow()

require(magrittr)
o_idat |>
    f_garbitu(copypaste = TRUE) %>% `[[`('df_aldaketak') |> 
    nrow()

## -----------------------------------------------------------------------------
require(dplyr)
o_idat$df_aldaketak |>
    select(author) |>
    head(10)
f_IDentifikau(o_idat, anonimu = TRUE)$df_aldaketak |>
    select(egileak) |>
    head(10)

## -----------------------------------------------------------------------------
# o_idat <- f_IDAT(fitxategia, kokapena)
f_ekitaldiak(o_idat$df_aldaketak) |> 
    group_by(ekitaldia) |> 
    filter(n()>4) |> 
    ungroup() |> 
    select(ekitaldia, charBank) |> 
    tail(10)

## -----------------------------------------------------------------------------
require(stringr)

f_idatzia(o_idat$df_aldaketak,
          lerru = F, etenak = F, ezabatuak = F, copypaste = F, lerroko_jauziak = F) |> suppressWarnings() |> 
    filter(egileak == levels(egileak)[3]) |> 
    select(idatzia) |> unlist() |> unname() |> 
    paste(collapse = "") |> 
    str_replace_all('\n\n\n', '\n\n') |> 
    cat()

## -----------------------------------------------------------------------------
f_idatzia(o_idat$df_aldaketak,
          lerru = T, etenak = F, ezabatuak = F, copypaste = F, lerroko_jauziak = F) |> suppressWarnings() |> 
    filter(egileak == levels(egileak)[3]) |> 
    select(idatzia) |> unlist() |> unname() |> 
    paste(collapse = "") |> 
    str_replace_all('\n\n\n', '\n\n') |> 
    cat()

## -----------------------------------------------------------------------------
f_idatzia(o_idat$df_aldaketak, lerru = F, etenak = T, dm = 20000,
          ezabatuak = F, copypaste = F, lerroko_jauziak = F) |> suppressWarnings() |> 
    filter(egileak == levels(egileak)[3]) |> 
    select(idatzia) |> unlist() |> unname() |> 
    paste(collapse = "") |> 
    str_replace_all('\n\n\n', '\n\n') |> 
    cat()

## -----------------------------------------------------------------------------
f_idatzia(o_idat$df_aldaketak, lerru = F, 
          etenak = F, dm = 3000, ezabatuak = T,
          copypaste = F, lerroko_jauziak = F) |> suppressWarnings() |> 
    filter(egileak == levels(egileak)[3]) |> 
    select(idatzia) |> unlist() |> unname() |> 
    paste(collapse = "") |> 
    str_replace_all('\n\n\n', '\n\n') |> 
    cat()

## -----------------------------------------------------------------------------
f_idatzia(o_idat$df_aldaketak, lerru = F, 
          etenak = F, dm = 20000, ezabatuak = F, copypaste = T,
           lerroko_jauziak = F) |> suppressWarnings() |> 
    filter(egileak == levels(egileak)[3]) |> 
    select(idatzia) |> unlist() |> unname() |> 
    paste(collapse = "") |> 
    str_replace_all('\n\n\n', '\n\n') |> 
    cat()

## -----------------------------------------------------------------------------
f_idatzia(o_idat$df_aldaketak, lerru = T,
          etenak = F, dm = 20000, 
          ezabatuak = F, copypaste = F, lerroko_jauziak = T) |> suppressWarnings() |> 
    filter(egileak == levels(egileak)[3]) |> 
    select(idatzia) |> unlist() |> unname() |> 
    paste(collapse = "") |> 
    str_replace_all('\n\n\n', '\n') |> 
    cat()

